"""The version number defined here is read automatically in setup.py."""

__version__ = "0.10.0.dev20210623"
